java: src/main/java/ejercicio04/apartado01.java
mpi: src/ejercicios/ejercicio02/apartado02.c
mpi: src/ejercicios/ejercicio03/apartado03.c numMensajes minTam [ maxTam incTam ]
